#ifndef NOTEBOOK_H
#define NOTEBOOK_H

#include "Produto.h"

class Notebook : public Produto
{
private:
    float comprimento;
    float largura;
    string processador;
    string memoria;
public:
    void setComprimento(float);
    float getComprimento();
    void setLargura(float);
    float getLargura();
    void setProcessador(string);
    string getProcessador();
    void setMemoria(string);
    string getMemoria();
};

#endif