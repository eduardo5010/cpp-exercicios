#include "Estoque.h"


void Estoque::atualizarNotebook()
{
    Notebook notebook;
    int codigo;
    bool encontrado = false;
    // Atualizar notebook
    cout << "--- ATUALIZAR NOTEBOOK ---" << endl;
    cout << "Digite o código do notebook (digite 0 para cancelar): ";
    cin >> codigo;
    if (codigo != 0)
    {
        ifstream listaNotebooks;
        listaNotebooks.open("Notebooks.txt", ios::in); // Abrindo arquivo no modo leitura
        if (!listaNotebooks)
        {
            cout << "Nenhum notebook cadastrado." << endl;
        }
        else
        {
            listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo

            while (listaNotebooks && !listaNotebooks.eof())
            {                                                                               // enquanto n�o for fim de arquivo...
                notebooks.push_back(notebook);                                              // Carregando na lista de notebooks
                listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo
            }
            listaNotebooks.close(); // Fechando arquivo no modo leitura

            // Comparando os dados inseridos com os dados da lista de notebooks
            for (int i = 0; i < notebooks.size(); i++)
            {
                if (notebooks[i].getCodigo() == codigo) // Se encontrar o notebook
                {
                    encontrado = true;
                    int escolha;
                    cout << "O que deseja atualizar?" << endl;
                    cout << "1) Nome" << endl;
                    cout << "2) Modelo" << endl;
                    cout << "3) Marca" << endl;
                    cout << "4) Preco" << endl;
                    cout << "5) Quantidade" << endl;
                    cout << "6) Comprimento" << endl;
                    cout << "7) Largura" << endl;
                    cout << "8) Processador" << endl;
                    cout << "9) Memoria" << endl;
                    cout << "0) VOLTAR" << endl;
                    cin >> escolha;
                    do
                    {
                        switch (escolha)
                        {
                        case 1:
                        {
                            string nome;
                            cout << "Digite o novo nome: ";
                            fflush(stdin);
                            getline(cin, nome);     // Recebendo novo nome
                            notebook.setNome(nome); // Atualizando nome

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setProcessador(notebooks[i].getProcessador());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 2:
                        {
                            string modelo;
                            cout << "Digite o novo modelo: ";
                            fflush(stdin);
                            getline(cin, modelo);       // Recebendo novo modelo
                            notebook.setModelo(modelo); // Atualizando modelo

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setProcessador(notebooks[i].getProcessador());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 3:
                        {
                            string marca;
                            cout << "Digite a nova marca: ";
                            fflush(stdin);
                            getline(cin, marca);      // Recebendo nova marca
                            notebook.setMarca(marca); // Atualizando marca

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setProcessador(notebooks[i].getProcessador());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 4:
                        {
                            double preco;
                            cout << "Digite o novo preco: ";
                            cin >> preco;             // Recebendo novo preco
                            notebook.setPreco(preco); // Atualizando preco

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setProcessador(notebooks[i].getProcessador());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 5:
                        {
                            int quantidade;
                            cout << "Digite a nova quantidade: ";
                            cin >> quantidade;                  // Recebendo nova quantidade
                            notebook.setQuantidade(quantidade); // Atualizando quantidade

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setProcessador(notebooks[i].getProcessador());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 6:
                        {
                            float comprimento;
                            cout << "Digite o novo comprimento: ";
                            cin >> comprimento;                   // Recebendo novo comprimento
                            notebook.setComprimento(comprimento); // Atualizando comprimento

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setProcessador(notebooks[i].getProcessador());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 7:
                        {
                            float largura;
                            cout << "Digite a nova largura: ";
                            cin >> largura;               // Recebendo nova largura
                            notebook.setLargura(largura); // Atualizando largura

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setProcessador(notebooks[i].getProcessador());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 8:
                        {
                            string processador;
                            cout << "Digite o novo processador: ";
                            fflush(stdin);
                            getline(cin, processador);            // Recebendo novo processador
                            notebook.setProcessador(processador); // Atualizando processador

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setMemoria(notebooks[i].getMemoria());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 9:
                        {
                            string memoria;
                            cout << "Digite a nova memoria: ";
                            fflush(stdin);
                            getline(cin, memoria);        // Recebendo nova memoria
                            notebook.setMemoria(memoria); // Atualizando memoria

                            // Transferindo dados inalterados para nova instância do objeto
                            notebook.setCodigo(notebooks[i].getCodigo());
                            notebook.setNome(notebooks[i].getNome());
                            notebook.setModelo(notebooks[i].getModelo());
                            notebook.setMarca(notebooks[i].getMarca());
                            notebook.setPreco(notebooks[i].getPreco());
                            notebook.setQuantidade(notebooks[i].getQuantidade());
                            notebook.setComprimento(notebooks[i].getComprimento());
                            notebook.setLargura(notebooks[i].getLargura());
                            notebook.setProcessador(notebooks[i].getProcessador());

                            notebooks.erase(notebooks.begin() + i); // Apagando notebook desatualizado da lista
                            notebooks.push_back(notebook);          // Insere notebook atualizado na lista

                            ofstream listaNotebooks;
                            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

                            if (!listaNotebooks)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < notebooks.size(); i++)
                            {
                                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
                            }
                            listaNotebooks.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 0:
                        {
                            break;
                        }
                        default:
                        {
                            // Opção inválida
                            cout << "Opção inválida. Tente novamente." << endl;
                            break;
                        }
                        }
                    } while (escolha != 0);
                    break;
                }
            }
            if (!encontrado) // Se não encontrar o notebook
            {
                cout << "Notebook não encontrado." << endl;
            }
        }
    }
    else
    {
    }
}
void Estoque::adicionarNotebook()
{
    Notebook notebook;
    string nome;
    string modelo;
    string marca;
    double preco;
    int quantidade;
    float comprimento;
    float largura;
    string processador;
    string memoria;
    // Adicionar notebook
    cout << "--- ADICIONAR NOTEBOOK ---" << endl;
    cout << "Digite o nome do notebook: ";
    fflush(stdin);
    getline(cin, nome);
    cout << "Digite o modelo do notebook: ";
    fflush(stdin);
    getline(cin, modelo);
    cout << "Digite a marca do notebook: ";
    fflush(stdin);
    getline(cin, marca);
    cout << "Digite o preco do notebook: ";
    cin >> preco;
    cout << "Digite a quantidade do notebook: ";
    cin >> quantidade;
    cout << "Digite o comprimento do notebook: ";
    cin >> comprimento;
    cout << "Digite a largura do notebook: ";
    cin >> largura;
    cout << "Digite o processador do notebook: ";
    fflush(stdin);
    getline(cin, processador);
    cout << "Digite a memoria do notebook: ";
    fflush(stdin);
    getline(cin, memoria);

    notebook.setNome(nome);
    notebook.setModelo(modelo);
    notebook.setMarca(marca);
    notebook.setPreco(preco);
    notebook.setQuantidade(quantidade);
    notebook.setComprimento(comprimento);
    notebook.setLargura(largura);
    notebook.setProcessador(processador);
    notebook.setMemoria(memoria);

    ifstream listaNotebooks;
    listaNotebooks.open("Notebooks.txt", ios::in); // Abrindo arquivo no modo leitura
    if (!listaNotebooks)
    {
        listaNotebooks.close(); // Fechando arquivo no modo leitura;

        notebook.setCodigo(1);

        notebooks.push_back(notebook); // Adicionando novo notebook na lista

        ofstream listaNotebooks;
        listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

        if (!listaNotebooks)
        {
            cout << "Não foi possível abrir o arquivo" << endl;
        }
        for (int i = 0; i < notebooks.size(); i++)
        {
            listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
        }
        listaNotebooks.close(); // Fechando arquivo no modo gravação
    }
    else
    {
        listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo

        while (listaNotebooks && !listaNotebooks.eof())
        {                                                                               // enquanto n�o for fim de arquivo...
            notebooks.push_back(notebook);                                              // Carregando na lista
            listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo
        }
        listaNotebooks.close(); // Fechando arquivo no modo leitura

        notebook.setCodigo(notebooks.size() + 1);

        notebooks.push_back(notebook); // Adicionando notebook na lista

        ofstream listaNotebooks;
        listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

        if (!listaNotebooks)
        {
            cout << "Não foi possível abrir o arquivo" << endl;
        }
        for (int i = 0; i < notebooks.size(); i++)
        {
            listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
        }
        listaNotebooks.close(); // Fechando arquivo no modo gravação
    }
}
void Estoque::removerNotebook()
{
    Notebook notebook;
    int codigo;
    bool encontrado;
    // Remover notebook
    cout << "--- REMOVER NOTEBOOK ---" << endl;
    cout << "Digite o código do notebook (digite 0 para cancelar): ";
    cin >> codigo;
    if (codigo != 0)
    {
        ifstream listaNotebooks;
        listaNotebooks.open("Notebooks.txt", ios::in); // abre arquivo para leitura
        if (!listaNotebooks)
        {
            cout << "Nenhum notebook cadastrado." << endl;
        }
        else
        {
            listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo

            while (listaNotebooks && !listaNotebooks.eof())
            {                                                                               // enquanto n�o for fim de arquivo...
                notebooks.push_back(notebook);                                              // Carregando na lista
                listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo
            }
            // Comparando os dados inseridos com os dados da lista de notebooks
            for (int i = 0; i < notebooks.size(); i++)
            {
                if (notebooks[i].getCodigo() == codigo)
                {
                    encontrado = true;
                    notebooks.erase(notebooks.begin() + i);
                }
                break;
            }
            if (!encontrado) // Se não encontrar o notebook
            {
                cout << "Notebook não encontrado." << endl;
            }

            listaNotebooks.close(); // Fechando arquivo no modo leitura

            ofstream listaNotebooks;
            listaNotebooks.open("Notebooks.txt"); // Abrindo arquivo no modo gravação

            if (!listaNotebooks)
            {
                cout << "Não foi possível abrir o arquivo" << endl;
            }
            for (int i = 0; i < notebooks.size(); i++)
            {
                listaNotebooks.write(reinterpret_cast<const char *>(&notebooks[i]), sizeof(Notebook)); // grava no arquivo
            }
            listaNotebooks.close(); // Fechando arquivo no modo gravação
        }
    }
}
void Estoque::exibirNotebook()
{
    Notebook notebook;
    int codigo;
    bool encontrado;
    // Exibir notebook
    cout << "--- EXIBIR NOTEBOOK ---" << endl;
    cout << "Digite o código do notebook (digite 0 para cancelar): ";
    cin >> codigo;
    if (codigo != 0)
    {
        ifstream listaNotebooks;
        listaNotebooks.open("Notebooks.txt", ios::in); // abre arquivo para leitura
        if (!listaNotebooks)
        {
            cout << "Nenhum notebook cadastrado." << endl;
        }
        else
        {
            listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo

            while (listaNotebooks && !listaNotebooks.eof())
            {                                                                               // enquanto n�o for fim de arquivo...
                notebooks.push_back(notebook);                                              // Carregando na lista
                listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo
            }
            // Comparando os dados inseridos com os dados da lista de notebooks
            for (int i = 0; i < notebooks.size(); i++)
            {
                if (notebooks[i].getCodigo() == codigo)
                {
                    encontrado = true;
                    cout << "Codigo: " << notebooks[i].getCodigo() << endl;
                    cout << "Nome: " << notebooks[i].getNome() << endl;
                    cout << "Modelo: " << notebooks[i].getModelo() << endl;
                    cout << "Marca: " << notebooks[i].getMarca() << endl;
                    cout << "Preco: " << notebooks[i].getPreco() << endl;
                    cout << "Quantidade: " << notebooks[i].getQuantidade() << endl;
                    cout << "Comprimento: " << notebooks[i].getComprimento() << endl;
                    cout << "Largura: " << notebooks[i].getLargura() << endl;
                    cout << "Processador: " << notebooks[i].getProcessador() << endl;
                    cout << "Memoria: " << notebooks[i].getMemoria() << endl;
                }
                break;
            }
            if (!encontrado) // Se não encontrar o notebook
            {
                cout << "Notebook não encontrado." << endl;
            }
            listaNotebooks.close(); // Fechando arquivo no modo leitura
        }
    }
}
void Estoque::exibirListaNotebook()
{
    Notebook notebook;
    ifstream listaNotebooks;
    listaNotebooks.open("Notebooks.txt", ios::in); // abre arquivo para leitura
    if (!listaNotebooks)
    {
        cout << "Nenhum notebook cadastrado." << endl;
    }
    else
    {
        listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo

        while (listaNotebooks && !listaNotebooks.eof())
        {                                                                               // enquanto n�o for fim de arquivo...
            notebooks.push_back(notebook);                                              // Carregando na lista
            listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo
        }
        // Comparando os dados inseridos com os dados da lista de notebooks
        for (int i = 0; i < notebooks.size(); i++)
        {

            cout << "Codigo: " << notebooks[i].getCodigo() << endl;
            cout << "Nome: " << notebooks[i].getNome() << endl;
            cout << "Modelo: " << notebooks[i].getModelo() << endl;
            cout << "Marca: " << notebooks[i].getMarca() << endl;
            cout << "Preco: " << notebooks[i].getPreco() << endl;
            cout << "Quantidade: " << notebooks[i].getQuantidade() << endl;
            cout << "Comprimento: " << notebooks[i].getComprimento() << endl;
            cout << "Largura: " << notebooks[i].getLargura() << endl;
            cout << "Processador: " << notebooks[i].getProcessador() << endl;
            cout << "Memoria: " << notebooks[i].getMemoria() << endl
                 << endl;
        }
        listaNotebooks.close(); // Fechando arquivo no modo leitura
    }
}
void Estoque::atualizarTV()
{
    TV tv;
    int codigo;
    bool encontrado = false;
    // Atualizar TV
    cout << "--- ATUALIZAR TV ---" << endl;
    cout << "Digite o código da TV (digite 0 para cancelar): ";
    cin >> codigo;
    if (codigo != 0)
    {
        ifstream listaTVs;
        listaTVs.open("TVs.txt", ios::in); // Abrindo arquivo no modo leitura
        if (!listaTVs)
        {
            cout << "Nenhuma TV cadastrada." << endl;
        }
        else
        {
            listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo

            while (listaTVs && !listaTVs.eof())
            {                                                             // enquanto n�o for fim de arquivo...
                tvs.push_back(tv);                                        // Carregando na lista de TVs
                listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo
            }
            listaTVs.close(); // Fechando arquivo no modo leitura

            // Comparando os dados inseridos com os dados da lista de TVs
            for (int i = 0; i < notebooks.size(); i++)
            {
                if (notebooks[i].getCodigo() == codigo) // Se encontrar a TV
                {
                    encontrado = true;
                    int escolha;
                    cout << "O que deseja atualizar?" << endl;
                    cout << "1) Nome" << endl;
                    cout << "2) Modelo" << endl;
                    cout << "3) Marca" << endl;
                    cout << "4) Preco" << endl;
                    cout << "5) Quantidade" << endl;
                    cout << "6) Comprimento" << endl;
                    cout << "7) Largura" << endl;
                    cout << "8) Tela" << endl;
                    cout << "9) Tecnologia" << endl;
                    cout << "0) VOLTAR" << endl;
                    cin >> escolha;
                    do
                    {
                        switch (escolha)
                        {
                        case 1:
                        {
                            string nome;
                            cout << "Digite o novo nome: ";
                            fflush(stdin);
                            getline(cin, nome); // Recebendo novo nome
                            tv.setNome(nome);   // Atualizando nome

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setLargura(tvs[i].getLargura());
                            tv.setTela(tvs[i].getTela());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 2:
                        {
                            string modelo;
                            cout << "Digite o novo modelo: ";
                            fflush(stdin);
                            getline(cin, modelo); // Recebendo novo modelo
                            tv.setModelo(modelo); // Atualizando modelo

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setLargura(tvs[i].getLargura());
                            tv.setTela(tvs[i].getTela());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 3:
                        {
                            string marca;
                            cout << "Digite a nova marca: ";
                            fflush(stdin);
                            getline(cin, marca); // Recebendo nova marca
                            tv.setMarca(marca);  // Atualizando marca

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setLargura(tvs[i].getLargura());
                            tv.setTela(tvs[i].getTela());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 4:
                        {
                            double preco;
                            cout << "Digite o novo preco: ";
                            cin >> preco;       // Recebendo novo preco
                            tv.setPreco(preco); // Atualizando preco

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setLargura(tvs[i].getLargura());
                            tv.setTela(tvs[i].getTela());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 5:
                        {
                            int quantidade;
                            cout << "Digite a nova quantidade: ";
                            cin >> quantidade;            // Recebendo nova quantidade
                            tv.setQuantidade(quantidade); // Atualizando quantidade

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setLargura(tvs[i].getLargura());
                            tv.setTela(tvs[i].getTela());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 6:
                        {
                            float comprimento;
                            cout << "Digite o novo comprimento: ";
                            cin >> comprimento;             // Recebendo novo comprimento
                            tv.setComprimento(comprimento); // Atualizando comprimento

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setLargura(tvs[i].getLargura());
                            tv.setTela(tvs[i].getTela());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 7:
                        {
                            float largura;
                            cout << "Digite a nova largura: ";
                            cin >> largura;         // Recebendo nova largura
                            tv.setLargura(largura); // Atualizando largura

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setTela(tvs[i].getTela());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 8:
                        {
                            string tela;
                            cout << "Digite a nova tela: ";
                            fflush(stdin);
                            getline(cin, tela); // Recebendo nova tela
                            tv.setTela(tela);   // Atualizando tela

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setLargura(tvs[i].getLargura());
                            tv.setTecnologia(tvs[i].getTecnologia());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 9:
                        {
                            string tecnologia;
                            cout << "Digite a nova tecnologia: ";
                            fflush(stdin);
                            getline(cin, tecnologia);     // Recebendo nova tecnologia
                            tv.setTecnologia(tecnologia); // Atualizando tecnologia

                            // Transferindo dados inalterados para nova instância do objeto
                            tv.setCodigo(tvs[i].getCodigo());
                            tv.setNome(tvs[i].getNome());
                            tv.setModelo(tvs[i].getModelo());
                            tv.setMarca(tvs[i].getMarca());
                            tv.setPreco(tvs[i].getPreco());
                            tv.setQuantidade(tvs[i].getQuantidade());
                            tv.setComprimento(tvs[i].getComprimento());
                            tv.setTela(tvs[i].getTela());

                            tvs.erase(tvs.begin() + i); // Apagando TV desatualizada da lista
                            tvs.push_back(tv);          // Insere TV atualizada na lista

                            ofstream listaTVs;
                            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

                            if (!listaTVs)
                            {
                                cout << "Não foi possível abrir o arquivo" << endl;
                                break;
                            }
                            for (int i = 0; i < tvs.size(); i++)
                            {
                                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
                            }
                            listaTVs.close(); // Fechando arquivo no modo gravação
                            break;
                        }
                        case 0:
                        {
                            break;
                        }
                        default:
                        {
                            // Opção inválida
                            cout << "Opção inválida. Tente novamente." << endl;
                            break;
                        }
                        }
                    } while (escolha != 0);
                    break;
                }
            }
            if (!encontrado) // Se não encontrar o notebook
            {
                cout << "TV não encontrada." << endl;
            }
        }
    }
}
void Estoque::adicionarTV()
{
    TV tv;
    string nome;
    string modelo;
    string marca;
    double preco;
    int quantidade;
    float comprimento;
    float largura;
    string tela;
    string tecnologia;
    // Adicionar TV
    cout << "--- ADICIONAR TV ---" << endl;
    cout << "Digite o nome da TV: ";
    fflush(stdin);
    getline(cin, nome);
    cout << "Digite o modelo da TV: ";
    fflush(stdin);
    getline(cin, modelo);
    cout << "Digite a marca da TV: ";
    fflush(stdin);
    getline(cin, marca);
    cout << "Digite o preco da TV: ";
    cin >> preco;
    cout << "Digite a quantidade da TV: ";
    cin >> quantidade;
    cout << "Digite o comprimento da TV: ";
    cin >> comprimento;
    cout << "Digite a largura da TV: ";
    cin >> largura;
    cout << "Digite a tela da TV: ";
    fflush(stdin);
    getline(cin, tela);
    cout << "Digite a tecnologia da TV: ";
    fflush(stdin);
    getline(cin, tecnologia);

    tv.setNome(nome);
    tv.setModelo(modelo);
    tv.setMarca(marca);
    tv.setPreco(preco);
    tv.setQuantidade(quantidade);
    tv.setComprimento(comprimento);
    tv.setLargura(largura);
    tv.setTela(tela);
    tv.setTecnologia(tecnologia);

    ifstream listaTVs;
    listaTVs.open("TVs.txt", ios::in); // Abrindo arquivo no modo leitura
    if (!listaTVs)
    {
        listaTVs.close(); // Fechando arquivo no modo leitura;

        tv.setCodigo(1);

        tvs.push_back(tv); // Adicionando novo notebook na lista

        ofstream listaTVs;
        listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

        if (!listaTVs)
        {
            cout << "Não foi possível abrir o arquivo" << endl;
        }
        for (int i = 0; i < tvs.size(); i++)
        {
            listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
        }
        listaTVs.close(); // Fechando arquivo no modo gravação
    }
    else
    {
        listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo

        while (listaTVs && !listaTVs.eof())
        {                                                             // enquanto n�o for fim de arquivo...
            tvs.push_back(tv);                                        // Carregando na lista
            listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo
        }
        listaTVs.close(); // Fechando arquivo no modo leitura

        tv.setCodigo(tvs.size() + 1);

        tvs.push_back(tv); // Adicionando TV na lista

        ofstream listaTVs;
        listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

        if (!listaTVs)
        {
            cout << "Não foi possível abrir o arquivo" << endl;
        }
        for (int i = 0; i < tvs.size(); i++)
        {
            listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
        }
        listaTVs.close(); // Fechando arquivo no modo gravação
    }
}
void Estoque::removerTV()
{
    TV tv;
    int codigo;
    bool encontrado;
    // Remover notebook
    cout << "--- REMOVER TV ---" << endl;
    cout << "Digite o código da TV (digite 0 para cancelar): ";
    cin >> codigo;
    if (codigo != 0)
    {
        ifstream listaTVs;
        listaTVs.open("TVs.txt", ios::in); // abre arquivo para leitura
        if (!listaTVs)
        {
            cout << "Nenhuma TV cadastrada." << endl;
        }
        else
        {
            listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo

            while (listaTVs && !listaTVs.eof())
            {                                                             // enquanto n�o for fim de arquivo...
                tvs.push_back(tv);                                        // Carregando na lista
                listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo
            }
            // Comparando os dados inseridos com os dados da lista de TVs
            for (int i = 0; i < tvs.size(); i++)
            {
                if (tvs[i].getCodigo() == codigo) // Se encontrar a TV
                {
                    encontrado = true;
                    tvs.erase(tvs.begin() + i);
                }
                break;
            }
            if (!encontrado) // Se não encontrar a TV
            {
                cout << "TV não encontrada." << endl;
            }

            listaTVs.close(); // Fechando arquivo no modo leitura

            ofstream listaTVs;
            listaTVs.open("TVs.txt"); // Abrindo arquivo no modo gravação

            if (!listaTVs)
            {
                cout << "Não foi possível abrir o arquivo" << endl;
            }
            for (int i = 0; i < tvs.size(); i++)
            {
                listaTVs.write(reinterpret_cast<const char *>(&tvs[i]), sizeof(TV)); // grava no arquivo
            }
            listaTVs.close(); // Fechando arquivo no modo gravação
        }
    }
}
void Estoque::exibirTV()
{
    TV tv;
    int codigo;
    bool encontrado;
    // Exibir notebook
    cout << "--- EXIBIR TV ---" << endl;
    cout << "Digite o código da TV (digite 0 para cancelar): ";
    cin >> codigo;
    if (codigo != 0)
    {
        ifstream listaTVs;
        listaTVs.open("TVs.txt", ios::in); // abre arquivo para leitura
        if (!listaTVs)
        {
            cout << "Nenhuma TV cadastrada." << endl;
        }
        else
        {
            listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo

            while (listaTVs && !listaTVs.eof())
            {                                                             // enquanto n�o for fim de arquivo...
                tvs.push_back(tv);                                        // Carregando na lista
                listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo
            }
            // Comparando os dados inseridos com os dados da lista de TVs
            for (int i = 0; i < tvs.size(); i++)
            {
                if (tvs[i].getCodigo() == codigo)
                {
                    encontrado = true;
                    cout << "Codigo: " << tvs[i].getCodigo() << endl;
                    cout << "Nome: " << tvs[i].getNome() << endl;
                    cout << "Modelo: " << tvs[i].getModelo() << endl;
                    cout << "Marca: " << tvs[i].getMarca() << endl;
                    cout << "Preco: " << tvs[i].getPreco() << endl;
                    cout << "Quantidade: " << tvs[i].getQuantidade() << endl;
                    cout << "Comprimento: " << tvs[i].getComprimento() << endl;
                    cout << "Largura: " << tvs[i].getLargura() << endl;
                    cout << "Tela: " << tvs[i].getTela() << endl;
                    cout << "Tecnologia: " << tvs[i].getTecnologia() << endl;
                }
                break;
            }
            if (!encontrado) // Se não encontrar a TV
            {
                cout << "TV não encontrada." << endl;
            }
            listaTVs.close(); // Fechando arquivo no modo leitura
        }
    }
}
void Estoque::exibirListaTV()
{
    TV tv;
    ifstream listaTVs;
    listaTVs.open("TVs.txt", ios::in); // abre arquivo para leitura
    if (!listaTVs)
    {
        cout << "Nenhuma TV cadastrada." << endl;
    }
    else
    {
        listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo

        while (listaTVs && !listaTVs.eof())
        {                                                             // enquanto n�o for fim de arquivo...
            tvs.push_back(tv);                                        // Carregando na lista
            listaTVs.read(reinterpret_cast<char *>(&tv), sizeof(TV)); // l� do arquivo
        }
        for (int i = 0; i < tvs.size(); i++)
        {

            cout << "Codigo: " << tvs[i].getCodigo() << endl;
            cout << "Nome: " << tvs[i].getNome() << endl;
            cout << "Modelo: " << tvs[i].getModelo() << endl;
            cout << "Marca: " << tvs[i].getMarca() << endl;
            cout << "Preco: " << tvs[i].getPreco() << endl;
            cout << "Quantidade: " << tvs[i].getQuantidade() << endl;
            cout << "Comprimento: " << tvs[i].getComprimento() << endl;
            cout << "Largura: " << tvs[i].getLargura() << endl;
            cout << "Tela: " << tvs[i].getTela() << endl;
            cout << "Tecnologia: " << tvs[i].getTecnologia() << endl
                 << endl;
        }
        listaTVs.close(); // Fechando arquivo no modo leitura
    }
}
void Estoque::adicionarNotebookCarrinho()
{
    Notebook notebook;
    int codigo;
    bool encontrado;
    // Exibir notebook
    cout << "--- ADICIONAR NOTEBOOK NO CARRINHO ---" << endl;
    cout << "Digite o código do notebook (digite 0 para cancelar): ";
    cin >> codigo;
    if (codigo != 0)
    {
        ifstream listaNotebooks;
        listaNotebooks.open("Notebooks.txt", ios::in); // abre arquivo para leitura
        if (!listaNotebooks)
        {
            cout << "Nenhum notebook cadastrado." << endl;
        }
        else
        {
            listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo

            while (listaNotebooks && !listaNotebooks.eof())
            {                                                                               // enquanto n�o for fim de arquivo...
                notebooks.push_back(notebook);                                              // Carregando na lista
                listaNotebooks.read(reinterpret_cast<char *>(&notebook), sizeof(Notebook)); // l� do arquivo
            }
            // Comparando os dados inseridos com os dados da lista de notebooks
            for (int i = 0; i < notebooks.size(); i++)
            {
                if (notebooks[i].getCodigo() == codigo)
                {
                    char escolha;
                    encontrado = true;
                    cout << "NOTEBOOK ENCONTRADO:" << endl;
                    cout << "Codigo: " << notebooks[i].getCodigo() << endl;
                    cout << "Nome: " << notebooks[i].getNome() << endl;
                    cout << "Modelo: " << notebooks[i].getModelo() << endl;
                    cout << "Marca: " << notebooks[i].getMarca() << endl;
                    cout << "Preco: " << notebooks[i].getPreco() << endl;
                    cout << "Quantidade: " << notebooks[i].getQuantidade() << endl;
                    cout << "Comprimento: " << notebooks[i].getComprimento() << endl;
                    cout << "Largura: " << notebooks[i].getLargura() << endl;
                    cout << "Processador: " << notebooks[i].getProcessador() << endl;
                    cout << "Memoria: " << notebooks[i].getMemoria() << endl;
                    cout << "ADICIONAR AO CARRINHO? (s/n): ";
                    cin >> escolha;
                    if(escolha == 's')
                    {
                        if(carrinhos.size() < 1)
                        {
                            CarrinhoDeCompras carrinho;
                            carrinho.setNumProduto(codigo);
                            carrinhos.push_back(carrinho);
                        }
                    }
                }
                break;
            }
            if (!encontrado) // Se não encontrar o notebook
            {
                cout << "Notebook não encontrado." << endl;
            }
            listaNotebooks.close(); // Fechando arquivo no modo leitura
        }
    }
}
void Estoque::adicionarTVCarrinho()
{
}
void Estoque::retirarNotebookCarrinho()
{
}
void Estoque::retirarTVCarrinho()
{
}
void Estoque::exibeCompraNotebookCarrinho()
{
}
void Estoque::exibeCompraTVCarrinho()
{
}
void Estoque::calculaPrecoListaNotebook()
{
}
void Estoque::calculaPrecoListaTV()
{
}
void Estoque::calculaPrecoTotal()
{
}
void Estoque::calculaDivida()
{
}