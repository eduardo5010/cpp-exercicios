#include "CarrinhoDeCompras.h"

int CarrinhoDeCompras::getNumCarrinho()
{

}
int CarrinhoDeCompras::getNumProduto()
{

}
int CarrinhoDeCompras::getQuantidade()
{

}
int CarrinhoDeCompras::getNumPedido()
{

}
float CarrinhoDeCompras::getCustoUnidade()
{

}
void CarrinhoDeCompras::setNumCarrinho(int)
{

}
void CarrinhoDeCompras::setNumProduto(int)
{

}
void CarrinhoDeCompras::setQuantidade(int)
{

}
void CarrinhoDeCompras::setNumPedido(int)
{

}
void CarrinhoDeCompras::setCustoUnidade(float)
{

}

void CarrinhoDeCompras::adicionarItemCarrinho()
{
}
void CarrinhoDeCompras::removerItemCarrinho()
{
}
void CarrinhoDeCompras::atualizarQuant()
{
}
void CarrinhoDeCompras::verDetalheCarrin()
{
}
void CarrinhoDeCompras::prossegCompra()
{
}
void CarrinhoDeCompras::finalizarPedido()
{
}
void CarrinhoDeCompras::calcularPreco()
{
}
void CarrinhoDeCompras::comprarProduto()
{
}
void CarrinhoDeCompras::carregarCarrinho()
{
}
void CarrinhoDeCompras::novoCarrinho()
{
}