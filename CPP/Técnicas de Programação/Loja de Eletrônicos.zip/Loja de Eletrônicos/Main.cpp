#include <iostream>
#include <fstream> // para fun��es de arquivo: ofstream e ifstream
#include <conio.h> // para getch()
#include <cstring> // para strncpy()
#include <string>
#include <iomanip> //para o setprecision
#include <vector>

using namespace std;

#include "Empresa.cpp"
#include "CarrinhoDeCompras.cpp"
#include "Estoque.cpp"
#include "Produto.cpp"
#include "Notebook.cpp"
#include "TV.cpp"

main()
{

    setlocale(LC_ALL, "Portuguese");

    // Instanciando objeto
    Estoque estoque;
    CarrinhoDeCompras compras;

    // Declarando variável
    int escolha;

    do
    {
        // Menu principal
        cout << "--- LOJA DE ELETRÔNICOS ---" << endl;
        cout << "1) FUNCIONÁRIO" << endl;
        cout << "2) COMPRAR PRODUTO" << endl;
        cout << "3) VERIFICAR ESTOQUE" << endl;
        cout << "4) CARRINHO DE COMPRAS" << endl;
        cout << "9) FECHAR O SISTEMA" << endl;
        cout << endl;
        cout << "Escolha uma opção: ";
        cin >> escolha;

        switch (escolha)
        {
        case 1:
        {
            int escolhaFuncionario;
            do
            {
                // Menu de funcionario
                cout << "--- FUNCIONARIO ---" << endl;
                cout << "1) ATUALIZAR NOTEBOOK" << endl;
                cout << "2) ATUALIZAR TV" << endl;
                cout << "3) ADICIONAR NOTEBOOK" << endl;
                cout << "4) ADICIONAR TV" << endl;
                cout << "5) REMOVER NOTEBOOK" << endl;
                cout << "6) REMOVER TV" << endl;
                cout << "7) VERIFICAR ESTOQUE" << endl;
                cout << "0) FECHAR O SISTEMA" << endl;
                cout << endl;
                cout << "Escolha uma opção: ";
                cin >> escolhaFuncionario;

                switch (escolhaFuncionario)
                {
                case 1:
                {
                    estoque.atualizarNotebook();
                    break;
                }
                case 2:
                {
                    estoque.atualizarTV();
                    break;
                }
                case 3:
                {
                    estoque.adicionarNotebook();
                    break;
                }
                case 4:
                {
                    estoque.adicionarTV();
                    break;
                }
                case 5:
                {
                    estoque.removerNotebook();
                    break;
                }
                case 6:
                {
                    estoque.removerTV();
                    break;
                }
                case 7:
                {
                    estoque.exibirListaNotebook();
                    estoque.exibirListaTV();
                    break;
                }
                case 0:
                {
                    break;
                }
                default:
                {
                    // Opção inválida
                    cout << "Opção inválida. Tente novamente." << endl;
                    break;
                }
                }
            } while (escolhaFuncionario != 0);

            break;
        }
        case 2:
        {
        }
        case 4:
            int escolhaCarrinho;
            do
            {
                // Carrinho de compras
                cout << "--- CARRINHO DE COMPRAS ---" << endl;
                cout << "1) ADICIONAR ITEM NO CARRINHO" << endl;
                cout << "2) RETIRAR ITEM DO CARRINHO" << endl;
                cout << "3) ATUALIZAR QUANTIDADE" << endl;
                cout << "4) VER DETALHES DO CARRINHO" << endl;
                cout << "5) PROSSEGUIR COMPRA" << endl;
                cout << "6) CARREGAR CARRINHO" << endl;
                cout << "7) CRIAR NOVO CARRINHO" << endl;
                cout << "9) VOLTAR" << endl;
                cout << endl;
                cout << "Escolha uma opção: ";
                cin >> escolhaCarrinho;
                switch (escolhaCarrinho)
                {
                case 1:
                {
                    compras.adicionarItemCarrinho();
                    break;
                }
                case 2:
                {
                    compras.removerItemCarrinho();
                    break;
                }
                case 3:
                {
                    compras.atualizarQuant();
                    break;
                }
                case 4:
                {
                    compras.verDetalheCarrin();
                    break;
                }
                case 5:
                {
                    compras.prossegCompra();
                    break;
                }
                case 6:
                {
                    compras.carregarCarrinho();
                    break;
                }
                case 7:
                {
                    compras.novoCarrinho();
                    break;
                }
                case 9:
                {
                    break;
                }

                default:
                {
                    // Opção inválida
                    cout << "Opção inválida. Tente novamente." << endl;
                    break;
                }
                }
            } while (escolhaCarrinho != 9);

        case 9:
        {
            break;
        }
        default:
        {
            // Opção inválida
            cout << "Opção inválida. Tente novamente." << endl;
            break;
        }
        }
        cout << endl;

    } while (escolha != 9);

    return 0;
}