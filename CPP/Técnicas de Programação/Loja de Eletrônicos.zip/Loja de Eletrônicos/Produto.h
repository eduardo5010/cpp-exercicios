#ifndef PRODUTO_H
#define PRODUTO_H

class Produto
{
protected:
    string nome;
    string modelo;
    string marca;
    double preco;
    int codigo;
    int quantidade;
public:
    void setNome(string);
    string getNome();
    void setModelo(string);
    string getModelo();
    void setMarca(string);
    string getMarca();
    void setPreco(double);
    double getPreco();
    void setCodigo(int);
    int getCodigo();
    void setQuantidade(int);
    int getQuantidade();
};

#endif