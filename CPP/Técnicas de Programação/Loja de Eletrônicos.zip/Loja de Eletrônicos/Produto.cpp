#include "Produto.h"

void Produto::setNome(string nome)
{
    this->nome = nome;
}
string Produto::getNome()
{
    return this->nome;
}
void Produto::setModelo(string modelo)
{
    this->modelo = modelo;
}
string Produto::getModelo()
{
    return this->modelo;
}
void Produto::setMarca(string marca)
{
    this->marca = marca;
}
string Produto::getMarca()
{
    return this->marca;
}
void Produto::setPreco(double preco)
{
    this->preco = preco;
}
double Produto::getPreco()
{
    return this->preco;
}
void Produto::setCodigo(int codigo)
{   
    this->codigo = codigo;
}
int Produto::getCodigo()
{   
    return this->codigo;
}
void Produto::setQuantidade(int quantidade)
{
    this->quantidade = quantidade;
}
int Produto::getQuantidade()
{
    return this->quantidade;
}