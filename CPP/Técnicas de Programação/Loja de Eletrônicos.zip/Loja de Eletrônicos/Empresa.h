#ifndef EMPRESA_H
#define EMPRESA_H

class Empresa
{
private:
    
    string nomeEmpresa;
    double dinheiroEmCaixa;
    double vendasMes;
public:
    void exibirLucroMensal();
};

#endif