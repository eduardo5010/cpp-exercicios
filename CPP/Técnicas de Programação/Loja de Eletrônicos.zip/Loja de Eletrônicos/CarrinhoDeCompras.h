#ifndef CARRINHODECOMPRAS_H
#define CARRINHODECOMPRAS_H

class CarrinhoDeCompras
{
private:
    int numCarrinho;
    vector <int> numProduto;
    vector <int> quantidade;
    int numPedido;
    vector <float> custoUnidade;
public:
    int getNumCarrinho();
    int getNumProduto();
    int getQuantidade();
    int getNumPedido();
    float getCustoUnidade();
    void setNumCarrinho(int);
    void setNumProduto(int);
    void setQuantidade(int);
    void setNumPedido(int);
    void setCustoUnidade(float);
    void adicionarItemCarrinho();
    void removerItemCarrinho();
    void atualizarQuant();
    void verDetalheCarrin();
    void prossegCompra();
    void finalizarPedido();
    void calcularPreco();
    void comprarProduto();
    void carregarCarrinho();
    void novoCarrinho();
};

#endif