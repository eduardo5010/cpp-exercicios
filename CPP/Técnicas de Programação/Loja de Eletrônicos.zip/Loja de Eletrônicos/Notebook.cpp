#include "Notebook.h"

void Notebook::setComprimento(float comprimento)
{
    this->comprimento = comprimento;
}
float Notebook::getComprimento()
{
    return this->comprimento;
}
void Notebook::setLargura(float largura)
{
    this->largura = largura;
}
float Notebook::getLargura()
{
    return this->largura;
}
void Notebook::setProcessador(string processador)
{
    this->processador = processador;
}
string Notebook::getProcessador()
{
    return this->processador;
}
void Notebook::setMemoria(string memoria)
{
    this->memoria = memoria;
}
string Notebook::getMemoria()
{
    return this->memoria;
}