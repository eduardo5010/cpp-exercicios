#include "TV.h"

void TV::setComprimento(float comprimento)
{
    this->comprimento = comprimento;
}
float TV::getComprimento()
{
    return this->comprimento;
}
void TV::setLargura(float largura)
{
    this->largura = largura;
}
float TV::getLargura()
{
    return this->largura;
}
void TV::setTela(string tela)
{
    this->tela = tela;
}
string TV::getTela()
{
    return this->tela;
}
void TV::setTecnologia(string tecnologia)
{
    this->tecnologia = tecnologia;
}
string TV::getTecnologia()
{
    return this->tecnologia;
}