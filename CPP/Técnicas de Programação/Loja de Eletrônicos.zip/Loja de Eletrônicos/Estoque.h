#ifndef ESTOQUE_H
#define ESTOQUE_H

#include "Notebook.h"
#include "TV.h"
#include "Produto.h"

class Estoque
{
private:
    double dinheiro;
    double desconto;
    double somaPreco;
    double divida;
    double valorTotal;
    vector<Notebook> notebooks;
    vector<TV> tvs;
    vector<CarrinhoDeCompras> carrinhos;
public:
    void atualizarNotebook();
    void adicionarNotebook();
    void removerNotebook();
    void exibirNotebook();
    void exibirListaNotebook();
    void atualizarTV();
    void adicionarTV();
    void removerTV();
    void exibirTV();
    void exibirListaTV();
    void adicionarNotebookCarrinho();
    void adicionarTVCarrinho();
    void retirarNotebookCarrinho();
    void retirarTVCarrinho();
    void exibeCompraNotebookCarrinho();
    void exibeCompraTVCarrinho();
    void calculaPrecoListaNotebook();
    void calculaPrecoListaTV();
    void calculaPrecoTotal();
    void calculaDivida();
};

#endif